using System;
using System.Windows.Forms;

namespace QRStudy.UI
{
    public partial class FrmBoasVindas : Form
    {
        public FrmBoasVindas()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmLogin frmLogin = new FrmLogin(modoFuncionarios: false);
            frmLogin.ShowDialog();
            this.Show();
        }

        private void btnCriarConta_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmCriarContaResponsavel frmCriar = new FrmCriarContaResponsavel();
            frmCriar.ShowDialog();
            this.Show();
        }

        private void btnFuncionarios_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmLogin frmLogin = new FrmLogin(modoFuncionarios: true);
            frmLogin.ShowDialog();
            this.Show();
        }
    }
}
