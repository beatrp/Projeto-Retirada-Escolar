using System;
using System.Windows.Forms;

namespace QRStudy.UI.Responsavel
{
    public partial class FrmResponsavelPainel : Form
    {
        private string nomeResponsavel;
        private int idResponsavel;
        private bool qrGerado = false;

        public FrmResponsavelPainel(string nome, int id)
        {
            InitializeComponent();
            nomeResponsavel = nome;
            idResponsavel = id;
            lblBoasVindas.Text = "Olá, " + nomeResponsavel + "!";
        }

        private void btnGerarQR_Click(object sender, EventArgs e)
        {
            qrGerado = true;
            btnGerarQR.Text = "Gerar Novo QR Code";
            lblQRInfo.Text = "QR Code Gerado com Sucesso!\nCódigo: QR-889911-ANA\nAluno: João Silva (5º Ano A)\nValidade: 5 minutos";
            pnlQR.BackColor = System.Drawing.Color.FromArgb(240, 253, 244);
        }

        private void btnPerfilAlunos_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "--- MEU PERFIL E ALUNOS VINCULADOS ---\n\n" +
                "Responsável: " + nomeResponsavel + "\n" +
                "E-mail: maria.silva@email.com\n" +
                "Telefone: (15) 99887-6655\n" +
                "CPF: 123.456.789-00\n\n" +
                "Alunos Vinculados:\n" +
                "1. João Silva - Turma: 5º Ano A (Manhã)\n" +
                "2. Ana Clara Silva - Turma: 3º Ano B (Manhã)",
                "Perfil do Responsável", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
