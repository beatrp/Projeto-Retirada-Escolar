using System;
using System.Data;
using System.Windows.Forms;

namespace QRStudy.UI.Administracao
{
    public partial class FrmAprovacaoTerceiros : Form
    {
        private DataTable dtTerceiros = new DataTable();

        public FrmAprovacaoTerceiros()
        {
            InitializeComponent();
            CarregarAutorizacoes();
        }

        private void CarregarAutorizacoes()
        {
            dtTerceiros.Columns.Add("Pessoa Autorizada", typeof(string));
            dtTerceiros.Columns.Add("CPF/RG", typeof(string));
            dtTerceiros.Columns.Add("Vínculo", typeof(string));
            dtTerceiros.Columns.Add("Aluno", typeof(string));
            dtTerceiros.Columns.Add("Data Autorizada", typeof(string));
            dtTerceiros.Columns.Add("Status", typeof(string));

            dtTerceiros.Rows.Add("Carlos Eduardo Silva", "123.456.789-00", "Avô", "João Silva", DateTime.Now.ToString("dd/MM/yyyy") + " 17:30", "Aguardando Escola");

            dgvTerceiros.DataSource = dtTerceiros;
        }

        private void btnAutorizar_Click(object sender, EventArgs e)
        {
            if (dgvTerceiros.CurrentRow != null)
            {
                dgvTerceiros.CurrentRow.Cells["Status"].Value = "Autorizado pela Escola";
                MessageBox.Show("Autorização temporária liberada para a Portaria!", "Autorização (RF-15)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
