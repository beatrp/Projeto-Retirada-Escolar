using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using QRStudy.UI.Portaria;
using QRStudy.UI.Administracao;
using QRStudy.UI.Responsavel;

namespace QRStudy.UI
{
    public partial class FrmLogin : Form
    {
        private string connectionString = "Server=LABHW-19;Database=QRStudyDB;Trusted_Connection=True;";
        private bool ehModoFuncionarios = false;

        public FrmLogin()
        {
            InitializeComponent();
        }

        public FrmLogin(bool modoFuncionarios) : this()
        {
            ehModoFuncionarios = modoFuncionarios;
            if (ehModoFuncionarios)
            {
                lblSubtitulo.Text = "Acesso Restrito a Funcionários / Escola";
                txtEmail.Text = "portaria@escolamodelo.edu.br";
            }
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string senha = txtSenha.Text.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(senha))
            {
                MessageBox.Show("Por favor, preencha o e-mail e a senha.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT id_usuario, nome, perfil FROM USUARIO WHERE email = @Email AND senha_hash = @Senha AND ativo = 1";
                    
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Senha", senha);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int idUsuario = reader.GetInt32(0);
                                string nome = reader.GetString(1);
                                string perfil = reader.GetString(2);

                                MessageBox.Show("Bem-vindo(a), " + nome + "!\nPerfil: " + perfil, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                RedirecionarPorPerfil(idUsuario, nome, perfil);
                            }
                            else
                            {
                                MessageBox.Show("E-mail ou senha inválidos!", "Erro de Autenticação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro de conexão SQL: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RedirecionarPorPerfil(int idUsuario, string nome, string perfil)
        {
            this.Hide();

            switch (perfil.ToUpper())
            {
                case "FUNCIONARIO":
                    FrmPortariaScanner frmScanner = new FrmPortariaScanner(nome, idUsuario);
                    frmScanner.ShowDialog();
                    break;

                case "ADMINISTRADOR":
                    FrmMenuPrincipal frmAdmin = new FrmMenuPrincipal(nome, perfil);
                    frmAdmin.ShowDialog();
                    break;

                case "RESPONSAVEL":
                    FrmResponsavelPainel frmResp = new FrmResponsavelPainel(nome, idUsuario);
                    frmResp.ShowDialog();
                    break;

                default:
                    MessageBox.Show("Perfil não reconhecido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Show();
                    return;
            }

            this.Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
