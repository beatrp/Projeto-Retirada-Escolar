using System;
using System.Windows.Forms;

namespace QRStudy.UI
{
    public partial class FrmCriarContaResponsavel : Form
    {
        public FrmCriarContaResponsavel()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNome.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtCPF.Text))
            {
                MessageBox.Show("Por favor, preencha todos os campos obrigatórios.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Cadastro realizado com sucesso! Seus documentos foram enviados para validação da escola.", "Sucesso (RF-02)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
