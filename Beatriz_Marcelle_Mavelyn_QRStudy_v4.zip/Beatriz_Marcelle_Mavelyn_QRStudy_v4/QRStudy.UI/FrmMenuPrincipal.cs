using System;
using System.Linq;
using System.Windows.Forms;
using QRStudy.UI.Administracao;
using QRStudy.UI.Portaria;

namespace QRStudy.UI
{
    public partial class FrmMenuPrincipal : Form
    {
        private string usuarioNome;
        private string usuarioPerfil;

        public FrmMenuPrincipal(string nome, string perfil)
        {
            InitializeComponent();
            usuarioNome = nome;
            usuarioPerfil = perfil;
            this.IsMdiContainer = true;
            
            // Alterar o fundo do container MDI cinza padrão para um tom moderno
            foreach (Control ctl in this.Controls)
            {
                if (ctl is MdiClient)
                {
                    ctl.BackColor = System.Drawing.Color.FromArgb(241, 245, 249);
                }
            }

            lblStatus.Text = "Usuário: " + usuarioNome + " | Perfil: " + usuarioPerfil + " | Banco: SQL Server (QRStudyDB)";
        }

        private void AbrirFormFilho<T>() where T : Form, new()
        {
            Form formExistente = this.MdiChildren.FirstOrDefault(f => f is T);

            if (formExistente != null)
            {
                formExistente.BringToFront();
                formExistente.Focus();
            }
            else
            {
                T novoForm = new T
                {
                    MdiParent = this,
                    StartPosition = FormStartPosition.CenterScreen
                };
                novoForm.Show();
            }
        }

        private void btnAlunos_Click(object sender, EventArgs e) => AbrirFormFilho<FrmGestaoAlunos>();
        private void btnAprovacaoCadastros_Click(object sender, EventArgs e) => AbrirFormFilho<FrmAprovacaoCadastros>();
        private void btnAutorizacoesTerceiros_Click(object sender, EventArgs e) => AbrirFormFilho<FrmAprovacaoTerceiros>();
        private void btnScannerPortaria_Click(object sender, EventArgs e) => AbrirFormFilho<FrmPortariaScanner>();

        private void menuAlunos_Click(object sender, EventArgs e) => AbrirFormFilho<FrmGestaoAlunos>();
        private void menuAprovacaoCadastros_Click(object sender, EventArgs e) => AbrirFormFilho<FrmAprovacaoCadastros>();
        private void menuAutorizacoesTerceiros_Click(object sender, EventArgs e) => AbrirFormFilho<FrmAprovacaoTerceiros>();
        private void menuPortariaScanner_Click(object sender, EventArgs e) => AbrirFormFilho<FrmPortariaScanner>();
        private void menuSair_Click(object sender, EventArgs e) => this.Close();
    }
}
