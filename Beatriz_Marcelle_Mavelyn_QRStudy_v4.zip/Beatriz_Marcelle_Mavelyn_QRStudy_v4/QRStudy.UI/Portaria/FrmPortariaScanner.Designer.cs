namespace QRStudy.UI.Portaria
{
    partial class FrmPortariaScanner
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblInstrucao;
        private System.Windows.Forms.TextBox txtCodigoQR;
        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Label lblStatusRetirada;
        private System.Windows.Forms.Label lblDetalhes;
        private System.Windows.Forms.Label lblOperador;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblInstrucao = new System.Windows.Forms.Label();
            this.txtCodigoQR = new System.Windows.Forms.TextBox();
            this.btnValidar = new System.Windows.Forms.Button();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.lblStatusRetirada = new System.Windows.Forms.Label();
            this.lblDetalhes = new System.Windows.Forms.Label();
            this.lblOperador = new System.Windows.Forms.Label();
            this.pnlResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblInstrucao
            // 
            this.lblInstrucao.AutoSize = true;
            this.lblInstrucao.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblInstrucao.Location = new System.Drawing.Point(30, 25);
            this.lblInstrucao.Name = "lblInstrucao";
            this.lblInstrucao.Size = new System.Drawing.Size(355, 20);
            this.lblInstrucao.Text = "Digite ou Posicione o Leitor de QR Code no Campo:";
            // 
            // txtCodigoQR
            // 
            this.txtCodigoQR.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtCodigoQR.Location = new System.Drawing.Point(30, 55);
            this.txtCodigoQR.Name = "txtCodigoQR";
            this.txtCodigoQR.Size = new System.Drawing.Size(430, 29);
            this.txtCodigoQR.Text = "QR-889911-ANA";
            // 
            // btnValidar
            // 
            this.btnValidar.BackColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnValidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValidar.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnValidar.ForeColor = System.Drawing.Color.White;
            this.btnValidar.Location = new System.Drawing.Point(475, 53);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(140, 33);
            this.btnValidar.Text = "Validar (RF-08)";
            this.btnValidar.UseVisualStyleBackColor = false;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // pnlResultado
            // 
            this.pnlResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResultado.Controls.Add(this.lblDetalhes);
            this.pnlResultado.Controls.Add(this.lblStatusRetirada);
            this.pnlResultado.Location = new System.Drawing.Point(30, 110);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(585, 200);
            // 
            // lblStatusRetirada
            // 
            this.lblStatusRetirada.AutoSize = true;
            this.lblStatusRetirada.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblStatusRetirada.Location = new System.Drawing.Point(20, 20);
            this.lblStatusRetirada.Name = "lblStatusRetirada";
            this.lblStatusRetirada.Size = new System.Drawing.Size(262, 30);
            this.lblStatusRetirada.Text = "Aguardando Leitura...";
            // 
            // lblDetalhes
            // 
            this.lblDetalhes.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDetalhes.Location = new System.Drawing.Point(20, 70);
            this.lblDetalhes.Name = "lblDetalhes";
            this.lblDetalhes.Size = new System.Drawing.Size(540, 110);
            this.lblDetalhes.Text = "Aproxime o QR Code do leitor para efetuar a validação.";
            // 
            // lblOperador
            // 
            this.lblOperador.AutoSize = true;
            this.lblOperador.Location = new System.Drawing.Point(30, 325);
            this.lblOperador.Name = "lblOperador";
            this.lblOperador.Size = new System.Drawing.Size(120, 17);
            this.lblOperador.Text = "Operador: Portaria";
            // 
            // FrmPortariaScanner
            // 
            this.ClientSize = new System.Drawing.Size(650, 360);
            this.Controls.Add(this.lblOperador);
            this.Controls.Add(this.pnlResultado);
            this.Controls.Add(this.btnValidar);
            this.Controls.Add(this.txtCodigoQR);
            this.Controls.Add(this.lblInstrucao);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validação da Portaria - Leitor de QR Code (RF-08)";
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
