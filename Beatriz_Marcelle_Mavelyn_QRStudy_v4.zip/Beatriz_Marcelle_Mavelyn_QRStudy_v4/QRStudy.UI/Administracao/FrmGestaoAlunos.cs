using System;
using System.Data;
using System.Windows.Forms;

namespace QRStudy.UI.Administracao
{
    public partial class FrmGestaoAlunos : Form
    {
        private DataTable dtAlunos = new DataTable();

        public FrmGestaoAlunos()
        {
            InitializeComponent();
            CarregarDadosSimulados();
        }

        private void CarregarDadosSimulados()
        {
            dtAlunos.Columns.Add("RA", typeof(string));
            dtAlunos.Columns.Add("Nome", typeof(string));
            dtAlunos.Columns.Add("Turma", typeof(string));
            dtAlunos.Columns.Add("Turno", typeof(string));

            dtAlunos.Rows.Add("1001", "João Silva", "5º Ano A", "Manhã");
            dtAlunos.Rows.Add("1002", "Ana Clara Souza", "3º Ano B", "Manhã");
            dtAlunos.Rows.Add("1003", "Lucas Gabriel Silva", "2º Ano EM", "Tarde");

            dgvAlunos.DataSource = dtAlunos;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtRA.Text) || string.IsNullOrEmpty(txtNome.Text))
            {
                MessageBox.Show("Preencha RA e Nome do aluno.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            dtAlunos.Rows.Add(txtRA.Text, txtNome.Text, txtTurma.Text, cmbTurno.Text);
            MessageBox.Show("Aluno cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtRA.Clear();
            txtNome.Clear();
            txtTurma.Clear();
        }
    }
}
