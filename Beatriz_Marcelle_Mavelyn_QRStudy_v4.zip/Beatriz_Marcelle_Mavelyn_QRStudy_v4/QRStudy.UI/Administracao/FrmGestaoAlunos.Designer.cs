namespace QRStudy.UI.Administracao
{
    partial class FrmGestaoAlunos
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.GroupBox grpCadastro;
        private System.Windows.Forms.Label lblRA;
        private System.Windows.Forms.TextBox txtRA;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblTurma;
        private System.Windows.Forms.TextBox txtTurma;
        private System.Windows.Forms.Label lblTurno;
        private System.Windows.Forms.ComboBox cmbTurno;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.DataGridView dgvAlunos;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpCadastro = new System.Windows.Forms.GroupBox();
            this.lblRA = new System.Windows.Forms.Label();
            this.txtRA = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblTurma = new System.Windows.Forms.Label();
            this.txtTurma = new System.Windows.Forms.TextBox();
            this.lblTurno = new System.Windows.Forms.Label();
            this.cmbTurno = new System.Windows.Forms.ComboBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.dgvAlunos = new System.Windows.Forms.DataGridView();
            this.grpCadastro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlunos)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCadastro
            // 
            this.grpCadastro.Controls.Add(this.btnSalvar);
            this.grpCadastro.Controls.Add(this.cmbTurno);
            this.grpCadastro.Controls.Add(this.lblTurno);
            this.grpCadastro.Controls.Add(this.txtTurma);
            this.grpCadastro.Controls.Add(this.lblTurma);
            this.grpCadastro.Controls.Add(this.txtNome);
            this.grpCadastro.Controls.Add(this.lblNome);
            this.grpCadastro.Controls.Add(this.txtRA);
            this.grpCadastro.Controls.Add(this.lblRA);
            this.grpCadastro.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpCadastro.Location = new System.Drawing.Point(10, 10);
            this.grpCadastro.Name = "grpCadastro";
            this.grpCadastro.Size = new System.Drawing.Size(740, 130);
            this.grpCadastro.Text = "Cadastrar Novo Aluno (RF-05)";
            // 
            // lblRA
            // 
            this.lblRA.AutoSize = true;
            this.lblRA.Location = new System.Drawing.Point(20, 30);
            this.lblRA.Text = "RA / Matrícula:";
            // 
            // txtRA
            // 
            this.txtRA.Location = new System.Drawing.Point(20, 50);
            this.txtRA.Size = new System.Drawing.Size(120, 25);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(160, 30);
            this.lblNome.Text = "Nome Completo:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(160, 50);
            this.txtNome.Size = new System.Drawing.Size(380, 25);
            // 
            // lblTurma
            // 
            this.lblTurma.AutoSize = true;
            this.lblTurma.Location = new System.Drawing.Point(560, 30);
            this.lblTurma.Text = "Turma:";
            // 
            // txtTurma
            // 
            this.txtTurma.Location = new System.Drawing.Point(560, 50);
            this.txtTurma.Size = new System.Drawing.Size(150, 25);
            // 
            // lblTurno
            // 
            this.lblTurno.AutoSize = true;
            this.lblTurno.Location = new System.Drawing.Point(20, 85);
            this.lblTurno.Text = "Turno:";
            // 
            // cmbTurno
            // 
            this.cmbTurno.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTurno.Items.AddRange(new object[] { "Manhã", "Tarde", "Integral" });
            this.cmbTurno.Location = new System.Drawing.Point(70, 82);
            this.cmbTurno.Size = new System.Drawing.Size(150, 25);
            this.cmbTurno.Text = "Manhã";
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSalvar.ForeColor = System.Drawing.Color.White;
            this.btnSalvar.Location = new System.Drawing.Point(560, 80);
            this.btnSalvar.Size = new System.Drawing.Size(150, 32);
            this.btnSalvar.Text = "Salvar Aluno";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // dgvAlunos
            // 
            this.dgvAlunos.AllowUserToAddRows = false;
            this.dgvAlunos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAlunos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAlunos.Location = new System.Drawing.Point(10, 140);
            this.dgvAlunos.Name = "dgvAlunos";
            this.dgvAlunos.ReadOnly = true;
            this.dgvAlunos.Size = new System.Drawing.Size(740, 310);
            // 
            // FrmGestaoAlunos
            // 
            this.ClientSize = new System.Drawing.Size(760, 460);
            this.Controls.Add(this.dgvAlunos);
            this.Controls.Add(this.grpCadastro);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.Name = "FrmGestaoAlunos";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestão de Alunos (RF-05)";
            this.grpCadastro.ResumeLayout(false);
            this.grpCadastro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlunos)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
