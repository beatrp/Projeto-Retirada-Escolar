using System;
using System.Drawing;
using System.Windows.Forms;

namespace QRStudy.UI.Portaria
{
    public partial class FrmPortariaScanner : Form
    {
        private string nomeOperador;
        private int idOperador;

        public FrmPortariaScanner()
        {
            InitializeComponent();
        }

        public FrmPortariaScanner(string operador, int id) : this()
        {
            nomeOperador = operador;
            idOperador = id;
            lblOperador.Text = "Operador: " + nomeOperador;
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            string codigoQR = txtCodigoQR.Text.Trim();

            if (string.IsNullOrEmpty(codigoQR))
            {
                MessageBox.Show("Por favor, digite ou posicione o leitor de QR Code no campo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (codigoQR.Equals("QR-889911-ANA", StringComparison.OrdinalIgnoreCase))
            {
                pnlResultado.BackColor = Color.FromArgb(220, 252, 231);
                lblStatusRetirada.ForeColor = Color.FromArgb(22, 101, 52);
                lblStatusRetirada.Text = "RETIRADA AUTORIZADA ✓";
                lblDetalhes.Text = "Aluno: João Silva (5º Ano A)\nResponsável: Maria Silva (Mãe)\nData/Hora: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            }
            else
            {
                pnlResultado.BackColor = Color.FromArgb(254, 226, 226);
                lblStatusRetirada.ForeColor = Color.FromArgb(153, 27, 27);
                lblStatusRetirada.Text = "RETIRADA NEGADA ✕";
                lblDetalhes.Text = "Motivo: QR Code Expirado, Inválido ou Não Cadastrado.";
            }
        }
    }
}
