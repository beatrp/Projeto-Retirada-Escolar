namespace QRStudy.UI.Responsavel
{
    partial class FrmResponsavelPainel
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblBoasVindas;
        private System.Windows.Forms.Button btnGerarQR;
        private System.Windows.Forms.Button btnPerfilAlunos;
        private System.Windows.Forms.Button btnVoltar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Panel pnlQR;
        private System.Windows.Forms.Label lblQRInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblBoasVindas = new System.Windows.Forms.Label();
            this.btnGerarQR = new System.Windows.Forms.Button();
            this.btnPerfilAlunos = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.pnlQR = new System.Windows.Forms.Panel();
            this.lblQRInfo = new System.Windows.Forms.Label();
            this.pnlQR.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBoasVindas
            // 
            this.lblBoasVindas.AutoSize = true;
            this.lblBoasVindas.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblBoasVindas.ForeColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.lblBoasVindas.Location = new System.Drawing.Point(30, 20);
            this.lblBoasVindas.Name = "lblBoasVindas";
            this.lblBoasVindas.Size = new System.Drawing.Size(180, 30);
            this.lblBoasVindas.Text = "Olá, Responsável!";
            // 
            // btnPerfilAlunos
            // 
            this.btnPerfilAlunos.BackColor = System.Drawing.Color.FromArgb(241, 245, 249);
            this.btnPerfilAlunos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerfilAlunos.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnPerfilAlunos.ForeColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnPerfilAlunos.Location = new System.Drawing.Point(30, 65);
            this.btnPerfilAlunos.Name = "btnPerfilAlunos";
            this.btnPerfilAlunos.Size = new System.Drawing.Size(470, 35);
            this.btnPerfilAlunos.Text = "Ver Meus Dados e Alunos Vinculados";
            this.btnPerfilAlunos.UseVisualStyleBackColor = false;
            this.btnPerfilAlunos.Click += new System.EventHandler(this.btnPerfilAlunos_Click);
            // 
            // btnGerarQR
            // 
            this.btnGerarQR.BackColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnGerarQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGerarQR.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnGerarQR.ForeColor = System.Drawing.Color.White;
            this.btnGerarQR.Location = new System.Drawing.Point(30, 115);
            this.btnGerarQR.Name = "btnGerarQR";
            this.btnGerarQR.Size = new System.Drawing.Size(470, 45);
            this.btnGerarQR.Text = "Gerar QR Code de Saída";
            this.btnGerarQR.UseVisualStyleBackColor = false;
            this.btnGerarQR.Click += new System.EventHandler(this.btnGerarQR_Click);
            // 
            // pnlQR
            // 
            this.pnlQR.BackColor = System.Drawing.Color.FromArgb(248, 250, 252);
            this.pnlQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlQR.Controls.Add(this.lblQRInfo);
            this.pnlQR.Location = new System.Drawing.Point(30, 175);
            this.pnlQR.Name = "pnlQR";
            this.pnlQR.Size = new System.Drawing.Size(470, 110);
            // 
            // lblQRInfo
            // 
            this.lblQRInfo.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.lblQRInfo.Location = new System.Drawing.Point(15, 15);
            this.lblQRInfo.Name = "lblQRInfo";
            this.lblQRInfo.Size = new System.Drawing.Size(440, 80);
            this.lblQRInfo.Text = "Pressione o botão acima para gerar ou renovar o QR Code de retirada escolar.";
            // 
            // btnVoltar
            // 
            this.btnVoltar.Location = new System.Drawing.Point(30, 305);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(225, 40);
            this.btnVoltar.Text = "Voltar ao Início";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(239, 68, 68);
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(275, 305);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(225, 40);
            this.btnSair.Text = "Sair da Aplicação";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FrmResponsavelPainel
            // 
            this.ClientSize = new System.Drawing.Size(530, 365);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.pnlQR);
            this.Controls.Add(this.btnGerarQR);
            this.Controls.Add(this.btnPerfilAlunos);
            this.Controls.Add(this.lblBoasVindas);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Painel do Responsável - QRStudy";
            this.pnlQR.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
