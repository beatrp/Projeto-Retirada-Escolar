# QRStudy - Sistema de Retirada Escolar por QR Code

## Visão Geral
Projeto acadêmico desenvolvido para a disciplina de Linguagem de Programação VIII da Fatec Itapetininga (Prof. José Almeida).

## Mapeamento de Requisitos Atendidos
- **RF-01:** Tela de Boas-Vindas / Portal Inicial (`FrmBoasVindas`)
- **RF-02 / UC02:** Validação e Cadastro de Responsáveis e Documentos (`FrmCriarContaResponsavel` e `FrmAprovacaoCadastros`)
- **RF-05 / UC05:** Gestão e Cadastro de Alunos (`FrmGestaoAlunos`)
- **RF-08 / UC08:** Leitura e Validação Instantânea de QR Code na Portaria (`FrmPortariaScanner`)
- **RF-10 / UC10:** Histórico e Consulta de Registros de Retiradas
- **RF-13 / UC13:** Autenticação e Roteamento Dinâmico por Perfil
- **RF-15 / UC15:** Aprovação de Autorizações Temporárias de Retirada por Terceiros (`FrmAprovacaoTerceiros`)
