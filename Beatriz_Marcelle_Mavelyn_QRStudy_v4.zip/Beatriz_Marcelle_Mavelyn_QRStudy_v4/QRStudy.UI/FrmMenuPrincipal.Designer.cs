namespace QRStudy.UI
{
    partial class FrmMenuPrincipal
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuCadastros;
        private System.Windows.Forms.ToolStripMenuItem menuAlunos;
        private System.Windows.Forms.ToolStripMenuItem menuAprovacaoCadastros;
        private System.Windows.Forms.ToolStripMenuItem menuAutorizacoesTerceiros;
        private System.Windows.Forms.ToolStripMenuItem menuPortaria;
        private System.Windows.Forms.ToolStripMenuItem menuPortariaScanner;
        private System.Windows.Forms.ToolStripMenuItem menuSair;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;
        private System.Windows.Forms.Panel pnlDashboard;
        private System.Windows.Forms.Label lblDashTitulo;
        private System.Windows.Forms.Button btnAlunos;
        private System.Windows.Forms.Button btnAprovacaoCadastros;
        private System.Windows.Forms.Button btnAutorizacoesTerceiros;
        private System.Windows.Forms.Button btnScannerPortaria;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuCadastros = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAlunos = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAprovacaoCadastros = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAutorizacoesTerceiros = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPortaria = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPortariaScanner = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSair = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.pnlDashboard = new System.Windows.Forms.Panel();
            this.lblDashTitulo = new System.Windows.Forms.Label();
            this.btnAlunos = new System.Windows.Forms.Button();
            this.btnAprovacaoCadastros = new System.Windows.Forms.Button();
            this.btnAutorizacoesTerceiros = new System.Windows.Forms.Button();
            this.btnScannerPortaria = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.pnlDashboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuCadastros,
            this.menuPortaria,
            this.menuSair});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 27);
            // 
            // menuCadastros
            // 
            this.menuCadastros.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAlunos,
            this.menuAprovacaoCadastros,
            this.menuAutorizacoesTerceiros});
            this.menuCadastros.Name = "menuCadastros";
            this.menuCadastros.Size = new System.Drawing.Size(110, 23);
            this.menuCadastros.Text = "Administração";
            // 
            // menuAlunos
            // 
            this.menuAlunos.Name = "menuAlunos";
            this.menuAlunos.Size = new System.Drawing.Size(300, 24);
            this.menuAlunos.Text = "Gestão de Alunos (RF-05)";
            this.menuAlunos.Click += new System.EventHandler(this.menuAlunos_Click);
            // 
            // menuAprovacaoCadastros
            // 
            this.menuAprovacaoCadastros.Name = "menuAprovacaoCadastros";
            this.menuAprovacaoCadastros.Size = new System.Drawing.Size(300, 24);
            this.menuAprovacaoCadastros.Text = "Aprovação de Responsáveis (RF-02)";
            this.menuAprovacaoCadastros.Click += new System.EventHandler(this.menuAprovacaoCadastros_Click);
            // 
            // menuAutorizacoesTerceiros
            // 
            this.menuAutorizacoesTerceiros.Name = "menuAutorizacoesTerceiros";
            this.menuAutorizacoesTerceiros.Size = new System.Drawing.Size(300, 24);
            this.menuAutorizacoesTerceiros.Text = "Autorização de Terceiros (RF-15)";
            this.menuAutorizacoesTerceiros.Click += new System.EventHandler(this.menuAutorizacoesTerceiros_Click);
            // 
            // menuPortaria
            // 
            this.menuPortaria.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.menuPortariaScanner });
            this.menuPortaria.Name = "menuPortaria";
            this.menuPortaria.Size = new System.Drawing.Size(69, 23);
            this.menuPortaria.Text = "Portaria";
            // 
            // menuPortariaScanner
            // 
            this.menuPortariaScanner.Name = "menuPortariaScanner";
            this.menuPortariaScanner.Size = new System.Drawing.Size(250, 24);
            this.menuPortariaScanner.Text = "Scanner de QR Code (RF-08)";
            this.menuPortariaScanner.Click += new System.EventHandler(this.menuPortariaScanner_Click);
            // 
            // menuSair
            // 
            this.menuSair.Name = "menuSair";
            this.menuSair.Size = new System.Drawing.Size(43, 23);
            this.menuSair.Text = "Sair";
            this.menuSair.Click += new System.EventHandler(this.menuSair_Click);
            // 
            // pnlDashboard
            // 
            this.pnlDashboard.BackColor = System.Drawing.Color.White;
            this.pnlDashboard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDashboard.Controls.Add(this.btnScannerPortaria);
            this.pnlDashboard.Controls.Add(this.btnAutorizacoesTerceiros);
            this.pnlDashboard.Controls.Add(this.btnAprovacaoCadastros);
            this.pnlDashboard.Controls.Add(this.btnAlunos);
            this.pnlDashboard.Controls.Add(this.lblDashTitulo);
            this.pnlDashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlDashboard.Location = new System.Drawing.Point(0, 27);
            this.pnlDashboard.Name = "pnlDashboard";
            this.pnlDashboard.Size = new System.Drawing.Size(984, 110);
            // 
            // lblDashTitulo
            // 
            this.lblDashTitulo.AutoSize = true;
            this.lblDashTitulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblDashTitulo.ForeColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.lblDashTitulo.Location = new System.Drawing.Point(20, 12);
            this.lblDashTitulo.Name = "lblDashTitulo";
            this.lblDashTitulo.Size = new System.Drawing.Size(248, 21);
            this.lblDashTitulo.Text = "Painel de Controle Administrativo";
            // 
            // btnAlunos
            // 
            this.btnAlunos.BackColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnAlunos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlunos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlunos.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAlunos.ForeColor = System.Drawing.Color.White;
            this.btnAlunos.Location = new System.Drawing.Point(24, 45);
            this.btnAlunos.Name = "btnAlunos";
            this.btnAlunos.Size = new System.Drawing.Size(220, 48);
            this.btnAlunos.Text = "👤 Gestão de Alunos";
            this.btnAlunos.UseVisualStyleBackColor = false;
            this.btnAlunos.Click += new System.EventHandler(this.btnAlunos_Click);
            // 
            // btnAprovacaoCadastros
            // 
            this.btnAprovacaoCadastros.BackColor = System.Drawing.Color.FromArgb(16, 185, 129);
            this.btnAprovacaoCadastros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAprovacaoCadastros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAprovacaoCadastros.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAprovacaoCadastros.ForeColor = System.Drawing.Color.White;
            this.btnAprovacaoCadastros.Location = new System.Drawing.Point(260, 45);
            this.btnAprovacaoCadastros.Name = "btnAprovacaoCadastros";
            this.btnAprovacaoCadastros.Size = new System.Drawing.Size(220, 48);
            this.btnAprovacaoCadastros.Text = "📄 Aprovar Pais / Docs";
            this.btnAprovacaoCadastros.UseVisualStyleBackColor = false;
            this.btnAprovacaoCadastros.Click += new System.EventHandler(this.btnAprovacaoCadastros_Click);
            // 
            // btnAutorizacoesTerceiros
            // 
            this.btnAutorizacoesTerceiros.BackColor = System.Drawing.Color.FromArgb(245, 158, 11);
            this.btnAutorizacoesTerceiros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAutorizacoesTerceiros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutorizacoesTerceiros.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAutorizacoesTerceiros.ForeColor = System.Drawing.Color.White;
            this.btnAutorizacoesTerceiros.Location = new System.Drawing.Point(496, 45);
            this.btnAutorizacoesTerceiros.Name = "btnAutorizacoesTerceiros";
            this.btnAutorizacoesTerceiros.Size = new System.Drawing.Size(220, 48);
            this.btnAutorizacoesTerceiros.Text = "🔑 Autorizar Terceiros";
            this.btnAutorizacoesTerceiros.UseVisualStyleBackColor = false;
            this.btnAutorizacoesTerceiros.Click += new System.EventHandler(this.btnAutorizacoesTerceiros_Click);
            // 
            // btnScannerPortaria
            // 
            this.btnScannerPortaria.BackColor = System.Drawing.Color.FromArgb(99, 102, 241);
            this.btnScannerPortaria.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScannerPortaria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScannerPortaria.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnScannerPortaria.ForeColor = System.Drawing.Color.White;
            this.btnScannerPortaria.Location = new System.Drawing.Point(732, 45);
            this.btnScannerPortaria.Name = "btnScannerPortaria";
            this.btnScannerPortaria.Size = new System.Drawing.Size(220, 48);
            this.btnScannerPortaria.Text = "📱 Scanner da Portaria";
            this.btnScannerPortaria.UseVisualStyleBackColor = false;
            this.btnScannerPortaria.Click += new System.EventHandler(this.btnScannerPortaria_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.lblStatus });
            this.statusStrip1.Location = new System.Drawing.Point(0, 639);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(984, 22);
            // 
            // lblStatus
            // 
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(118, 17);
            this.lblStatus.Text = "Sistema Conectado";
            // 
            // FrmMenuPrincipal
            // 
            this.BackColor = System.Drawing.Color.FromArgb(241, 245, 249);
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.pnlDashboard);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QRStudy - Sistema de Gestão e Controladoria Escolar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.pnlDashboard.ResumeLayout(false);
            this.pnlDashboard.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
