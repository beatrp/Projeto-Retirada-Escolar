using System;
using System.Data;
using System.Windows.Forms;

namespace QRStudy.UI.Administracao
{
    public partial class FrmAprovacaoCadastros : Form
    {
        private DataTable dtSolicitacoes = new DataTable();

        public FrmAprovacaoCadastros()
        {
            InitializeComponent();
            CarregarFilaAprovacao();
        }

        private void CarregarFilaAprovacao()
        {
            dtSolicitacoes.Columns.Add("ID", typeof(int));
            dtSolicitacoes.Columns.Add("Responsável", typeof(string));
            dtSolicitacoes.Columns.Add("Aluno Vinculado", typeof(string));
            dtSolicitacoes.Columns.Add("Documentos Enviados", typeof(string));
            dtSolicitacoes.Columns.Add("Status", typeof(string));

            dtSolicitacoes.Rows.Add(1, "Mariana Oliveira", "Lucas Oliveira (5º A)", "RG + Comprovante Residência", "Pendente");
            dtSolicitacoes.Rows.Add(2, "Ricardo Santos", "Beatriz Santos (3º B)", "CNH + Comprovante Residência", "Pendente");

            dgvFila.DataSource = dtSolicitacoes;
        }

        private void btnAprovar_Click(object sender, EventArgs e)
        {
            if (dgvFila.CurrentRow != null)
            {
                dgvFila.CurrentRow.Cells["Status"].Value = "Aprovado";
                MessageBox.Show("Vínculo do responsável aprovado com sucesso!", "Aprovação (RF-02)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
