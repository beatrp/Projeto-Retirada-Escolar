namespace QRStudy.UI.Administracao
{
    partial class FrmAprovacaoCadastros
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvFila;
        private System.Windows.Forms.Button btnAprovar;
        private System.Windows.Forms.Label lblInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvFila = new System.Windows.Forms.DataGridView();
            this.btnAprovar = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFila)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblInfo.Location = new System.Drawing.Point(15, 15);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(380, 20);
            this.lblInfo.Text = "Fila de Validação de Cadastros e Vínculos (RF-02):";
            // 
            // dgvFila
            // 
            this.dgvFila.AllowUserToAddRows = false;
            this.dgvFila.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFila.Location = new System.Drawing.Point(15, 45);
            this.dgvFila.Name = "dgvFila";
            this.dgvFila.ReadOnly = true;
            this.dgvFila.Size = new System.Drawing.Size(710, 320);
            // 
            // btnAprovar
            // 
            this.btnAprovar.BackColor = System.Drawing.Color.FromArgb(22, 101, 52);
            this.btnAprovar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAprovar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnAprovar.ForeColor = System.Drawing.Color.White;
            this.btnAprovar.Location = new System.Drawing.Point(545, 380);
            this.btnAprovar.Name = "btnAprovar";
            this.btnAprovar.Size = new System.Drawing.Size(180, 40);
            this.btnAprovar.Text = "Aprovar Vínculo";
            this.btnAprovar.UseVisualStyleBackColor = false;
            this.btnAprovar.Click += new System.EventHandler(this.btnAprovar_Click);
            // 
            // FrmAprovacaoCadastros
            // 
            this.ClientSize = new System.Drawing.Size(740, 440);
            this.Controls.Add(this.btnAprovar);
            this.Controls.Add(this.dgvFila);
            this.Controls.Add(this.lblInfo);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.Name = "FrmAprovacaoCadastros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aprovação de Responsáveis e Vínculos (RF-02)";
            ((System.ComponentModel.ISupportInitialize)(this.dgvFila)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
