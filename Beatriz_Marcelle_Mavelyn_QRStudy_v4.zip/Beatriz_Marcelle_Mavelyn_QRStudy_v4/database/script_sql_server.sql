-- ============================================================
-- SCRIPT DE CRIAÇÃO DO BANCO DE DADOS - QRSTUDY (SQL SERVER)
-- ============================================================

IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'QRStudyDB')
BEGIN
    CREATE DATABASE QRStudyDB;
END;
GO

USE QRStudyDB;
GO

-- 1. TABELA ESCOLA
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ESCOLA')
BEGIN
    CREATE TABLE ESCOLA (
        id_escola INT IDENTITY(1,1) PRIMARY KEY,
        nome_escola VARCHAR(150) NOT NULL,
        cnpj CHAR(14) NOT NULL UNIQUE,
        endereco VARCHAR(255) NOT NULL,
        telefone VARCHAR(20) NOT NULL,
        email_institucional VARCHAR(254) NOT NULL,
        email_confirmado BIT NOT NULL DEFAULT 0,
        status_cadastro VARCHAR(20) NOT NULL DEFAULT 'PENDENTE',
        ativo BIT NOT NULL DEFAULT 1,
        CONSTRAINT ck_escola_status CHECK (status_cadastro IN ('PENDENTE', 'APROVADA', 'REJEITADA'))
    );
END;
GO

-- 2. TABELA USUARIO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'USUARIO')
BEGIN
    CREATE TABLE USUARIO (
        id_usuario INT IDENTITY(1,1) PRIMARY KEY,
        id_escola INT NULL,
        nome VARCHAR(150) NOT NULL,
        email VARCHAR(254) NOT NULL UNIQUE,
        senha_hash VARCHAR(255) NOT NULL,
        perfil VARCHAR(20) NOT NULL,
        cpf VARCHAR(255) NULL,
        cpf_hash CHAR(64) NULL,
        telefone VARCHAR(20) NULL,
        turno VARCHAR(20) NULL,
        ativo BIT NOT NULL DEFAULT 1,
        tentativas_login SMALLINT NOT NULL DEFAULT 0,
        bloqueado_ate DATETIME2 NULL,
        CONSTRAINT fk_usuario_escola FOREIGN KEY (id_escola) REFERENCES ESCOLA (id_escola),
        CONSTRAINT ck_usuario_perfil CHECK (perfil IN ('ADMINISTRADOR', 'FUNCIONARIO', 'RESPONSAVEL'))
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'uq_usuario_cpf_hash')
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX uq_usuario_cpf_hash 
    ON USUARIO (cpf_hash) 
    WHERE cpf_hash IS NOT NULL;
END;
GO

-- 3. TABELA ALUNO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ALUNO')
BEGIN
    CREATE TABLE ALUNO (
        id_aluno INT IDENTITY(1,1) PRIMARY KEY,
        id_escola INT NOT NULL,
        nome_completo VARCHAR(150) NOT NULL,
        data_nascimento DATE NOT NULL,
        cpf VARCHAR(255) NULL,
        cpf_hash CHAR(64) NULL,
        serie VARCHAR(30) NOT NULL,
        turma VARCHAR(30) NOT NULL,
        matricula VARCHAR(30) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'ATIVO',
        turno VARCHAR(20) NOT NULL,
        foto VARCHAR(500) NULL,
        CONSTRAINT fk_aluno_escola FOREIGN KEY (id_escola) REFERENCES ESCOLA (id_escola),
        CONSTRAINT uq_aluno_matricula UNIQUE (id_escola, matricula)
    );
END;
GO

-- INSERÇÕES DE TESTE
IF NOT EXISTS (SELECT 1 FROM ESCOLA WHERE cnpj = '12345678000199')
BEGIN
    INSERT INTO ESCOLA (nome_escola, cnpj, endereco, telefone, email_institucional, email_confirmado, status_cadastro, ativo)
    VALUES ('Fatec Escola Modelo', '12345678000199', 'Rua das Flores, 100', '1533334444', 'contato@escolamodelo.edu.br', 1, 'APROVADA', 1);
END;

IF NOT EXISTS (SELECT 1 FROM USUARIO WHERE email = 'admin@escolamodelo.edu.br')
BEGIN
    INSERT INTO USUARIO (id_escola, nome, email, senha_hash, perfil, ativo)
    VALUES (1, 'Administrador Master', 'admin@escolamodelo.edu.br', '123456', 'ADMINISTRADOR', 1);
END;

IF NOT EXISTS (SELECT 1 FROM USUARIO WHERE email = 'portaria@escolamodelo.edu.br')
BEGIN
    INSERT INTO USUARIO (id_escola, nome, email, senha_hash, perfil, ativo)
    VALUES (1, 'Portaria Principal', 'portaria@escolamodelo.edu.br', '123456', 'FUNCIONARIO', 1);
END;

IF NOT EXISTS (SELECT 1 FROM USUARIO WHERE email = 'maria.silva@email.com')
BEGIN
    INSERT INTO USUARIO (id_escola, nome, email, senha_hash, perfil, ativo, cpf, telefone)
    VALUES (NULL, 'Maria Silva (Mãe)', 'maria.silva@email.com', '123456', 'RESPONSAVEL', 1, '123.456.789-00', '(15) 99887-6655');
END;

IF NOT EXISTS (SELECT 1 FROM ALUNO WHERE matricula = '1001')
BEGIN
    INSERT INTO ALUNO (id_escola, nome_completo, data_nascimento, serie, turma, matricula, turno, status)
    VALUES (1, 'João Silva', '2015-05-10', '5º Ano', 'A', '1001', 'Manhã', 'ATIVO');
END;
GO
