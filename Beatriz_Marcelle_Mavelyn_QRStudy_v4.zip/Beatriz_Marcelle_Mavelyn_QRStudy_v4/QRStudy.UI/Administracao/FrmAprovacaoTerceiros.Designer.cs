namespace QRStudy.UI.Administracao
{
    partial class FrmAprovacaoTerceiros
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvTerceiros;
        private System.Windows.Forms.Button btnAutorizar;
        private System.Windows.Forms.Label lblInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvTerceiros = new System.Windows.Forms.DataGridView();
            this.btnAutorizar = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTerceiros)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblInfo.Location = new System.Drawing.Point(15, 15);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(425, 20);
            this.lblInfo.Text = "Solicitações de Autorização Temporária por Terceiros (RF-15):";
            // 
            // dgvTerceiros
            // 
            this.dgvTerceiros.AllowUserToAddRows = false;
            this.dgvTerceiros.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTerceiros.Location = new System.Drawing.Point(15, 45);
            this.dgvTerceiros.Name = "dgvTerceiros";
            this.dgvTerceiros.ReadOnly = true;
            this.dgvTerceiros.Size = new System.Drawing.Size(710, 320);
            // 
            // btnAutorizar
            // 
            this.btnAutorizar.BackColor = System.Drawing.Color.FromArgb(2, 132, 199);
            this.btnAutorizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutorizar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnAutorizar.ForeColor = System.Drawing.Color.White;
            this.btnAutorizar.Location = new System.Drawing.Point(545, 380);
            this.btnAutorizar.Name = "btnAutorizar";
            this.btnAutorizar.Size = new System.Drawing.Size(180, 40);
            this.btnAutorizar.Text = "Liberar Saída (RF-15)";
            this.btnAutorizar.UseVisualStyleBackColor = false;
            this.btnAutorizar.Click += new System.EventHandler(this.btnAutorizar_Click);
            // 
            // FrmAprovacaoTerceiros
            // 
            this.ClientSize = new System.Drawing.Size(740, 440);
            this.Controls.Add(this.btnAutorizar);
            this.Controls.Add(this.dgvTerceiros);
            this.Controls.Add(this.lblInfo);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.Name = "FrmAprovacaoTerceiros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Autorizações Temporárias de Retirada (RF-15)";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTerceiros)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
